package com.tgate.gate.Activity;

import static com.tgate.gate.util.Constant.STORAGE_CODE;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.material.button.MaterialButton;
import com.jaiselrahman.filepicker.activity.FilePickerActivity;
import com.jaiselrahman.filepicker.config.Configurations;
import com.jaiselrahman.filepicker.model.MediaFile;
import com.tgate.gate.R;
import com.tgate.gate.apiResponse.CompanyDataResponse;
import com.tgate.gate.apiResponse.ContactlistGuardResponse;
import com.tgate.gate.util.Constant;
import com.tgate.gate.util.PrefsManager;
import com.tgate.gate.util.Utility;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class EditVisitorDetails extends AppCompatActivity {

    ImageView check_in_back, img_editimage, img_visitorimg;
    AppCompatTextView txt_date, txt_time, txt_document, edt_selecthost;
    AppCompatEditText edt_name, edit_email, edit_phone, edt_no_person;
    MaterialButton btn_submit;

    List<ContactlistGuardResponse.Datum> getContactlist;
    List<CompanyDataResponse.Datum> getCompanyDetail;

    //ImageUri
    Uri ProfileUri;

    //stor images uries in array list
    ArrayList<Bitmap> imagePathList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_visitor_details);

        edt_name = findViewById(R.id.edt_name);
        edit_email = findViewById(R.id.edit_email);
        edit_phone = findViewById(R.id.edit_phone);
        edt_no_person = findViewById(R.id.edt_no_person);
        img_visitorimg = findViewById(R.id.img_visitorimg);

        edt_selecthost = findViewById(R.id.edt_selecthost);
        edt_selecthost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Dialog_Host_List addBottomDialogFragment =
                        Dialog_Host_List.newInstance();
                addBottomDialogFragment.show(getSupportFragmentManager(),
                        "");

            }

        });

//        imagepicker();
        img_editimage = findViewById(R.id.img_editimage);
        img_editimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(EditVisitorDetails.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(EditVisitorDetails.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_CODE);
                } else {
//                    imagePicker();
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Select Image"), Constant.IMAGE_CODE);
                }
            }
        });
        txt_document = findViewById(R.id.txt_document);
        txt_document.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(EditVisitorDetails.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(EditVisitorDetails.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_CODE);
                } else {
//                    documentPicker();
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(intent, "Select Image"), Constant.Document_CODE);
                }
            }
        });

        check_in_back = findViewById(R.id.check_in_back);
        check_in_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

//        Log.d("@@@_IMAGE_CODE", String.valueOf(Constant.IMAGE_CODE));

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = dateFormat.format(calendar.getTime());
        txt_date =

                findViewById(R.id.txt_date);
        txt_date.setText(date);

        SimpleDateFormat timeFormet = new SimpleDateFormat("HH:mm a");
        String time = timeFormet.format(calendar.getTime());
        txt_time =

                findViewById(R.id.txt_time);
        txt_time.setText(time);

        btn_submit =

                findViewById(R.id.btn_submit);
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkValidation()) {

                    Utility.showMessage(EditVisitorDetails.this, true, "Submit successfully");
                }
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_CODE){
            if (grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                Utility.showMessage(EditVisitorDetails.this,true,"Permission Granted");
            }
            else {
                Utility.showMessage(EditVisitorDetails.this,true,"Permission  not Granted");

            }
        }
    }


    /*private void documentPicker() {
        Intent intent = new Intent(EditVisitorDetails.this, FilePickerActivity.class);
        intent.putExtra(FilePickerActivity.CONFIGS, new Configurations.Builder()
                .setCheckPermission(true)
                .setShowImages(true)
                .enableImageCapture(true)
                .setShowVideos(false)
                .setSuffixes("txt", "pdf", "html", "xml", "zip", "rar", "doc", "docx", "ppt")
                .setMaxSelection(5)
                .setSkipZeroSizeFiles(true)
                .build());

        startActivityForResult(intent, Constant.Document_CODE);
    }

    private void imagePicker() {
        Intent intent = new Intent(EditVisitorDetails.this, FilePickerActivity.class);
        intent.putExtra(FilePickerActivity.CONFIGS, new Configurations.Builder()
                .setCheckPermission(true)
                .setShowImages(true)
                .enableImageCapture(true)
                .setMaxSelection(1)
                .setSkipZeroSizeFiles(true)
                .build());

        startActivityForResult(intent, Constant.IMAGE_CODE);
    }*/


      @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == Constant.IMAGE_CODE && resultCode == RESULT_OK) {
            ProfileUri = data.getData();
            if (ProfileUri != null) {
                img_visitorimg.setImageURI(ProfileUri);
            }
        } else if (requestCode == Constant.Document_CODE && resultCode == RESULT_OK) {
            if (data.getClipData() != null) {
                imagePathList = new ArrayList<>();
                ClipData clipData = data.getClipData();
                if (clipData != null) {
//                int count = data.getClipData().getItemCount(); //number of picked images
                    for (int i = 0; i < clipData.getItemCount(); i++) {
                        Uri Documents = data.getClipData().getItemAt(i).getUri();
                        try {
                            InputStream is = getContentResolver().openInputStream(Documents);
                            Bitmap bitmap = BitmapFactory.decodeStream(is);
                            imagePathList.add(bitmap);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }

                } else {
                    Uri Documents = data.getData();
                    try {
                        InputStream is = getContentResolver().openInputStream(Documents);
                        Bitmap bitmap = BitmapFactory.decodeStream(is);
                        imagePathList.add(bitmap);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
            PrefsManager.savePrefsVal(PrefsManager.DOCUMENT_Url, String.valueOf(imagePathList));
            Log.d("@@@_Documents", PrefsManager.readStringPrefsVal(PrefsManager.DOCUMENT_Url));
      }
    }


    private boolean checkValidation() {

        if (isEmpty(edt_name)) {
            Utility.showMessage(EditVisitorDetails.this, false, "Please Enter Name");
            edt_name.requestFocus();
            return false;
        } else if (isEmpty(edit_email)) {
            Utility.showMessage(EditVisitorDetails.this, false, "Please Enter Email Id");
            edit_email.requestFocus();
            return false;
        } else if (!Utility.isEmail(edit_email.getText().toString().trim())) {
            Utility.showMessage(EditVisitorDetails.this, false, "Please Enter valid Email Id");
            edit_email.requestFocus();
            return false;
        } else if (isEmpty(edit_phone)) {
            Utility.showMessage(EditVisitorDetails.this, false, "Please Enter Phone Number");
            edit_phone.requestFocus();
            return false;
        } else if (ismobile(edit_phone)) {
            Utility.showMessage(EditVisitorDetails.this, false, "Please Enter valid Phone Number");
            edit_phone.requestFocus();
            return false;
        } else if (isEmpty(edt_no_person)) {
            Utility.showMessage(EditVisitorDetails.this, false, "Please Enter Number of Person");
            edt_no_person.requestFocus();
            return false;
        } else if (imagePathList == null) {
            Utility.showMessage(EditVisitorDetails.this, false, "Please select two Document");
            txt_document.requestFocus();
            return false;
        } else {
            return true;
        }
    }

    private boolean isEmpty(AppCompatEditText edt) {
        CharSequence str = edt.getText().toString().trim();
        return TextUtils.isEmpty(str);
    }

    private boolean ismobile(EditText edt) {
        int mlengh = edt.getText().length();
        if (mlengh == 10) {
            return false;
        } else {
            return true;
        }
    }
}