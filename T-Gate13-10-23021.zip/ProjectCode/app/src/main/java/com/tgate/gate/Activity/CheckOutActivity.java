package com.tgate.gate.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.tgate.gate.Adapter.checkoutListAdapter;
import com.tgate.gate.R;
import com.tgate.gate.model.getCheckoutList;

import java.util.ArrayList;
import java.util.List;

public class CheckOutActivity extends AppCompatActivity {

    ImageView check_out_back;
    RecyclerView rv_chechoutList;
    String name[];
    int images[] = {R.drawable.guru,R.drawable.guru,R.drawable.sanjay,R.drawable.guru,R.drawable.sanjay,
            R.drawable.guru,R.drawable.sanjay,R.drawable.guru,R.drawable.sanjay,R.drawable.guru};
    List<getCheckoutList> getCheckoutList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);

        check_out_back = findViewById(R.id.check_out_back);
        name = getResources().getStringArray(R.array.visitorname);
        check_out_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                overridePendingTransition(R.anim.trans_left_in,R.anim.trans_left_out);

            }
        });

        rv_chechoutList = findViewById(R.id.rv_chechoutList);

//        getCheckoutList = new ArrayList<>();
//
//        getCheckoutList getCheckoutall = new getCheckoutList();
//        getCheckoutall.setImage("");
//        getCheckoutall.setName("Mayur Zalavadiya");
//
//        for (int i =0; i<10; i++){
//            getCheckoutList.add(getCheckoutall);
//        }

        getCheckoutList = new ArrayList<>();


        for (int i =0; i<10; i++){
            getCheckoutList getCheckoutall = new getCheckoutList();
            getCheckoutall.setImage(images[i]);
            getCheckoutall.setName(name[i]);
            getCheckoutList.add(getCheckoutall);
        }

        checkoutListAdapter checkoutListAdapter = new checkoutListAdapter(this,getCheckoutList,images,name);
        rv_chechoutList.setLayoutManager(new LinearLayoutManager(CheckOutActivity.this));
        rv_chechoutList.setItemAnimator(new DefaultItemAnimator());
        rv_chechoutList.setAdapter(checkoutListAdapter);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.trans_right_in,R.anim.trans_right_out);

    }
}