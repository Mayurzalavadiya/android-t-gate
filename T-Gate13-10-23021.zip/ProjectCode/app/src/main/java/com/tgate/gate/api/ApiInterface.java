package com.tgate.gate.api;


import com.google.gson.JsonElement;
import com.tgate.gate.apiResponse.CheckInResponse;
import com.tgate.gate.apiResponse.CheckOutResponse;
import com.tgate.gate.apiResponse.CompanyDataResponse;
import com.tgate.gate.apiResponse.ContactlistGuardResponse;
import com.tgate.gate.apiResponse.ContactlistResponse;
import com.tgate.gate.apiResponse.ForgotPasswordResponse;
import com.tgate.gate.apiResponse.GetCheckOutResponse;
import com.tgate.gate.apiResponse.LoginGuardResponse;
import com.tgate.gate.apiResponse.LoginOwnerResponse;
import com.tgate.gate.apiResponse.SignUpResponse;
import com.tgate.gate.apiResponse.TokenupdateCopyOwnerResponse;
import com.tgate.gate.apiResponse.TokenupdateGuardResponse;
import com.tgate.gate.apiResponse.TokenupdateOwnerResponse;
import com.tgate.gate.apiResponse.VisitorDataGuardresponse;
import com.tgate.gate.apiResponse.VisitorPurposeGuardResponse;
import com.tgate.gate.apiResponse.VisitorStatusResponse;
import com.tgate.gate.apiResponse.VisitordataResponse;
import com.tgate.gate.apiResponse.VisitorpurposeResponse;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import retrofit2.http.Url;


public interface ApiInterface {

    @GET
    Call<JsonElement> getWebserviceCall(@Url String url);

    @GET
    Call<JsonElement> getWebserviceCall(@Url String url, @Header("Authorization") String authorization);

    @GET
    Call<JsonElement> getWebserviceCall(@Url String url, @QueryMap HashMap<String, Object> body);

    @POST
    Call<JsonElement> postWebserviceCall(@Url String url, @Body HashMap<String, Object> body);


   /* //Get Api Demo
    @GET("category/getCategory")
    Call<CommonResponse<List<GetCategorydata>>> getCategory();

    //PostApiDemo
    @POST("user/registration")
    Call<SignUpResponse> registration(@Body RegistrationRequest registrationRequest);


    //MultiPart Demo
    /*@Multipart
    @POST("schedule/saveBroadcastAndScheduledDetails")
    Call<AddBroadcastResponse<AddBroadcastScheduleResponse>> saveBroadcastAndScheduledDetails(@Part List<MultipartBody.Part> build, @Part MultipartBody.Part profileImage);*/


/////   /*    OWNER    */   /////

    //Login Owner
    @FormUrlEncoded
    @POST("login_auth")
    Call<LoginOwnerResponse> loginownerresponse(@Field("email") String email, @Field("password") String password, @Field("is_login") String is_login, @Field("fcm_token") String fcm_token,
                                                @Field("device_model") String device_model, @Field("device_osversion") String device_osversion, @Field("app_version") String app_version, @Field("device_type") String device_type);

    //Token Update Copy Owner
    @FormUrlEncoded
    @POST("login_auth/token_update")
    Call<TokenupdateCopyOwnerResponse> token_update_copy_owner_response(@Field("id") String id, @Field("fcm_token") String fcm_token, @Field("is_login") String is_login, @Field("device_type") String device_type);

    //Token Update Owner
    @FormUrlEncoded
    @POST("login_auth/token_update")
    Call<TokenupdateOwnerResponse> token_upte_owner_response(@Field("id") String id, @Field("fcm_token") String fcm_token, @Field("is_login") String is_login);

    //Signup
    @FormUrlEncoded
    @POST("signup_auth")
    Call<SignUpResponse> signupresponse(@Field("firstname") String firstname, @Field("lastname") String lastname, @Field("email") String email, @Field("company") String company);

    //Forgot password
    @FormUrlEncoded
    @POST("login_auth/forgotpassword")
    Call<ForgotPasswordResponse> forgotpasswordresponse(@Field("email") String email, @Field("is_login") String is_login);

    //Visitor Status
    @FormUrlEncoded
    @POST("visitors/visitors_status")
    Call<VisitorStatusResponse> visitor_status_response(@Field("id") String id, @Field("rejected_reason") String rejected_reason, @Field("status") String status);

    //Get VisitorData Owner
    @FormUrlEncoded
    @POST("visitors/get_visitors")
    Call<VisitordataResponse> visitor_data_response(@Field("clients_id") String clients_id, @Field("status") String status, @Field("offset") String offset, @Field("is_login") String is_login);

    //visitors purpose
    @GET("visitors_purpose")
    Call<VisitorpurposeResponse> visitorpurposeresponse();

    //contactlist
    @GET("contacts/get_contactlist/1")
    Call<ContactlistResponse> contactlistresponse();


/////   /*    GUARD    */   /////


    //Login Guard
    @FormUrlEncoded
    @POST("login_auth")
    Call<LoginGuardResponse> loginguardresponse(@Field("email") String email, @Field("password") String password, @Field("is_login") String is_login, @Field("fcm_token") String fcm_token,
                                                @Field("device_model") String device_model, @Field("device_osversion") String device_osversion, @Field("app_version") String app_version, @Field("device_type") String device_type);

    //Token Update
    @FormUrlEncoded
    @POST("login_auth/token_update")
    Call<TokenupdateGuardResponse> token_update_guard_response(@Field("id") String id, @Field("fcm_token") String fcm_token, @Field("is_login") String is_login, @Field("device_type") String device_type);

    //Visitor Purpose Update
    @GET("visitors_purpose")
    Call<VisitorPurposeGuardResponse> visitorpurpose_guard_response();

    //Customer && Company
    @GET("customers/get_company/2")
    Call<CompanyDataResponse> company_data_response();

    //ContactList
    @GET("contacts/get_contactlist/1")
    Call<ContactlistGuardResponse> contactlist_guard_response();

    //Visitor Check in
    @GET("visitors/get_visitors_checkin/1/1")
    Call<CheckInResponse> checkin_response();

    //Visitor getCheck Out
    @GET("visitors/get_visitors_checkout/1/1")
    Call<GetCheckOutResponse> getcheckout_response();

    //CheckOut
    @FormUrlEncoded
    @POST("visitors/visitors_checkout")
    Call<CheckOutResponse> checkout_response(@Field("id") String id, @Field("checkout_remark") String checkout_remark);

    //VisitorData
    @FormUrlEncoded
    @POST("visitors/get_visitors")
    Call<VisitorDataGuardresponse> visitordata_Guard_response(@Field("status") String status, @Field("offset") String offset, @Field("guard_id") String guard_id, @Field("is_login") String is_login);
}