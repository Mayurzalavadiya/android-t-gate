package com.tgate.gate.Activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.tgate.gate.Adapter.hostListAdapter;
import com.tgate.gate.Interface.Host_clickListener;
import com.tgate.gate.R;
import com.tgate.gate.api.RestClient;
import com.tgate.gate.apiResponse.ContactlistGuardResponse;
import com.tgate.gate.util.Utility;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Dialog_Host_List extends BottomSheetDialogFragment {

    List<ContactlistGuardResponse.Datum> getContactlist;
    Host_clickListener host_clickListener;
    RecyclerView rvhostlist;


    public static Dialog_Host_List newInstance() {
        return new Dialog_Host_List();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.dialog_host_list, container, false);

        rvhostlist = view.findViewById(R.id.rvhostlist);

        hostlist();

        rvhostlist.setLayoutManager(new LinearLayoutManager(getContext()));
        rvhostlist.setItemAnimator(new DefaultItemAnimator());


        return view;
    }

    private void hostlist() {
        if (Utility.isInternetAvailable(getContext())){
            RestClient.getInstance().getApiInterface().contactlist_guard_response().enqueue(new Callback<ContactlistGuardResponse>() {
                @Override
                public void onResponse(Call<ContactlistGuardResponse> call, Response<ContactlistGuardResponse> response) {
                    if (response.body().getData().size() > 0) {
                        getContactlist = response.body().getData();
                        hostListAdapter hostListAdapter = new hostListAdapter(getContext(), getContactlist);
                        rvhostlist.setAdapter(hostListAdapter);
                        hostListAdapter.notifyDataSetChanged();
                    } else {
                        Utility.showMessage(getActivity(), false, response.body().getMessage());
                    }
                }

                @Override
                public void onFailure(Call<ContactlistGuardResponse> call, Throwable t) {
                    Utility.showMessage(getActivity(), false, t.getMessage());
                }
            });
        }
    }

}