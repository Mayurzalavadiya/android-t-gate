package com.tgate.gate.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.widget.TextView;


import com.tgate.gate.R;
import com.tgate.gate.util.PrefsManager;
import com.tgate.gate.util.Utility;

public class SplashActivity extends AppCompatActivity {

    TextView txt_tgate;
    String is_login = PrefsManager.readStringPrefsVal(PrefsManager.IS_LOGIN);
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        //  getSupportActionBar().hide();

        txt_tgate = findViewById(R.id.txt_tgate);

        AlphaAnimation alphaAnimation = new AlphaAnimation(0, 1);
        alphaAnimation.setDuration(2800);
        txt_tgate.startAnimation(alphaAnimation);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (is_login!=null && is_login != "") {
                    Utility.Intent(SplashActivity.this, MainActivity.class);
                    finish();
                } else {
                    Utility.Intent(SplashActivity.this, LoginActivity.class);
                    finish();
                }
            }
        }, 3000);
    }
}