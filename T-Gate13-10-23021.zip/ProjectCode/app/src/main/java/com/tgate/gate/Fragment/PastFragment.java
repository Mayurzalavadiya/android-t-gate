package com.tgate.gate.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tgate.gate.Adapter.adminListAdapter;
import com.tgate.gate.R;
import com.tgate.gate.model.getAdminList;

import java.util.ArrayList;
import java.util.List;


public class PastFragment extends Fragment {
    RecyclerView rvVisitorList;
    List<getAdminList> getAdminLists;
    String visitorname[], visitorposs[], visitorexp[];


    public PastFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_past, container, false);

        rvVisitorList =view.findViewById(R.id.rvVisitorList);

        visitorname = getResources().getStringArray(R.array.visitorname);

        visitorposs = getResources().getStringArray(R.array.visitorposs);

        visitorexp = getResources().getStringArray(R.array.visitorExperience);

        getAdminLists = new ArrayList<>();
        for (int i = 0; i < visitorname.length; i++) {
            getAdminList getAdminList = new getAdminList();
            getAdminList.setVisitorName(visitorname[i]);
            getAdminList.setVisitorposs(visitorposs[i]);
            getAdminList.setVisitorexp(visitorexp[i]);
            getAdminList.setVisitorImage(R.drawable.guru);
            getAdminLists.add(getAdminList);


        }

        adminListAdapter adminListAdapter = new adminListAdapter(getContext(), getAdminLists, visitorname, visitorposs, visitorexp);
        rvVisitorList.setLayoutManager(new LinearLayoutManager(getContext()));
        rvVisitorList.setItemAnimator(new DefaultItemAnimator());
        rvVisitorList.setAdapter(adminListAdapter);

        return view;
    }
}