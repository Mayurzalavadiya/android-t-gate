package com.tgate.gate.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.tgate.gate.R;
import com.tgate.gate.apiResponse.ContactlistGuardResponse;
import com.tgate.gate.model.getHostList;
import com.tgate.gate.util.PrefsManager;
import com.tgate.gate.util.Utility;

import java.util.List;

public class hostListAdapter extends RecyclerView.Adapter<hostListAdapter.myHostListHolder> {

    Context context;
    List<ContactlistGuardResponse.Datum> getHostlist;
    String user_id;

//    int hostimage[];
//    String hostname[], hostposs[];
//    int counter = 1;


    public hostListAdapter(Context context, List<ContactlistGuardResponse.Datum> getHostlist) {
        this.context = context;
        this.getHostlist = getHostlist;
    }

    @NonNull
    @Override
    public myHostListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_host_list, parent,false);
        return new myHostListHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myHostListHolder holder, int position) {
//
//        if (counter<hostname.length){
//            holder.txt3_number.setText(getHostlist.get(position).setText(counter));
//            counter++;
//        }
        Glide.with(context).load(getHostlist.get(position).getProfileImage()).into(holder.img_hostimg);

        holder.txt_hostname.setText(getHostlist.get(position).getFirstname());
        holder.txt_hostpossition.setText(getHostlist.get(position).getLastname());
        holder.txt3_number.setText(getHostlist.get(position).getId());
        user_id = getHostlist.get(position).getUserid();

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PrefsManager.savePrefsVal(PrefsManager.CONTACT_USER_ID,user_id);
                Utility.showMessage((Activity) context,true,user_id);
            }
        });

    }

    @Override
    public int getItemCount() {
        return getHostlist.size();
    }


    public class myHostListHolder extends RecyclerView.ViewHolder {

        ImageView img_hostimg;
        AppCompatTextView txt_hostname;
        AppCompatTextView txt3_number;;
        AppCompatTextView txt_hostpossition;
        public myHostListHolder(@NonNull View itemView) {
            super(itemView);
            img_hostimg = itemView.findViewById(R.id.img_hostimg);
            txt_hostname = itemView.findViewById(R.id.txt_hostname);
            txt3_number = itemView.findViewById(R.id.txt3_number);
            txt_hostpossition = itemView.findViewById(R.id.txt_hostpossition);
        }
    }
}
