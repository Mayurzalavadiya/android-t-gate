package com.tgate.gate.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.tgate.gate.Activity.VisitorsActivity;
import com.tgate.gate.R;
import com.tgate.gate.model.getAdminList;

import java.util.List;

public class adminListAdapter extends RecyclerView.Adapter<adminListAdapter.myAdminListHolder> {
    Context context;
    List<getAdminList> getAdminLists;
    String visitorname[],visitorposs[],visitorexp[];

    public adminListAdapter(Context context, List<getAdminList> getAdminLists, String[] visitorname, String[] visitorposs, String[] visitorexp) {
        this.context = context;
        this.getAdminLists = getAdminLists;
        this.visitorname = visitorname;
        this.visitorposs = visitorposs;
        this.visitorexp = visitorexp;
    }

    @NonNull
    @Override
    public myAdminListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_admin_list, parent,false);
        return new myAdminListHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myAdminListHolder holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(context).load(getAdminLists.get(position).getVisitorImage()).into(holder.img_userimg);

        holder.txt_name.setText(getAdminLists.get(position).getVisitorName());
        holder.txt_poss.setText(getAdminLists.get(position).getVisitorposs());
        holder.txt_exp.setText(getAdminLists.get(position).getVisitorexp());
        holder.txt_reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomSheetDialog dialog_filter = new BottomSheetDialog(v.getContext(), R.style.alertDialogThem);
                dialog_filter.setContentView(R.layout.dialog_mettingowner);
                dialog_filter.setCanceledOnTouchOutside(true);

                ImageView img_close = dialog_filter.findViewById(R.id.img_close);
                img_close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog_filter.dismiss();
                    }
                });
                dialog_filter.show();
            }
        });

    }


    @Override
    public int getItemCount() {
        return getAdminLists.size();
    }

    public class myAdminListHolder extends RecyclerView.ViewHolder {
        AppCompatTextView txt_reject;
        ImageView img_userimg;
        AppCompatTextView txt_name,txt_poss,txt_exp, txt_accept;
        public myAdminListHolder(@NonNull View itemView) {
            super(itemView);
            img_userimg = itemView.findViewById(R.id.img_userimg);
            txt_reject = itemView.findViewById(R.id.txt_reject);
            txt_name = itemView.findViewById(R.id.txt_name);
            txt_poss = itemView.findViewById(R.id.txt_poss);
            txt_exp = itemView.findViewById(R.id.txt_exp);
        }
    }
}
