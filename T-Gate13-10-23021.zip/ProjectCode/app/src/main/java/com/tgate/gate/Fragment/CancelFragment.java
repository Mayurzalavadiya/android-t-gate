package com.tgate.gate.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tgate.gate.Adapter.visitorListAdapter;
import com.tgate.gate.R;
import com.tgate.gate.model.getVisitorList;

import java.util.ArrayList;
import java.util.List;

public class CancelFragment extends Fragment {

    RecyclerView rvVisitorList;
    List<com.tgate.gate.model.getVisitorList> getVisitorList;
    String visitorname[], visitorposs[], visitorexp[];

    public CancelFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cancel, container, false);
        rvVisitorList = view.findViewById(R.id.rvVisitorList);

        visitorname = getResources().getStringArray(R.array.visitorname);

        visitorposs = getResources().getStringArray(R.array.visitorposs);

        visitorexp = getResources().getStringArray(R.array.visitorExperience);

        getVisitorList = new ArrayList<>();
        for (int i = 0; i < visitorname.length; i++) {
            com.tgate.gate.model.getVisitorList getVisitorall = new getVisitorList();
            getVisitorall.setVisitorName(visitorname[i]);
            getVisitorall.setVisitorposs(visitorposs[i]);
            getVisitorall.setVisitorexp(visitorexp[i]);
            getVisitorall.setVisitorImage(R.drawable.guru);
            getVisitorList.add(getVisitorall);


        }

        visitorListAdapter visitorListAdapter = new visitorListAdapter(getContext(), getVisitorList, visitorname, visitorposs, visitorexp);
        rvVisitorList.setLayoutManager(new LinearLayoutManager(getContext()));
        rvVisitorList.setItemAnimator(new DefaultItemAnimator());
        rvVisitorList.setAdapter(visitorListAdapter);
        return view;
    }
}