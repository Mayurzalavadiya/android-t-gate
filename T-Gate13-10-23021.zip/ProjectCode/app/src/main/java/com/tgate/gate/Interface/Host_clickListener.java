package com.tgate.gate.Interface;

import com.tgate.gate.apiResponse.ContactlistGuardResponse;

public interface Host_clickListener {

    void clickIteam(ContactlistGuardResponse contactlistGuardResponse);
}
