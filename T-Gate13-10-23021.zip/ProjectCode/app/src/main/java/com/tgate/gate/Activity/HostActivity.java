package com.tgate.gate.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.tgate.gate.R;
import com.tgate.gate.api.RestClient;
import com.tgate.gate.apiResponse.CompanyDataResponse;
import com.tgate.gate.apiResponse.ContactlistGuardResponse;
import com.tgate.gate.model.getHostList;
import com.tgate.gate.Adapter.hostListAdapter;
import com.tgate.gate.util.PrefsManager;
import com.tgate.gate.util.Utility;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HostActivity extends AppCompatActivity {

    ImageView host_back;
    RecyclerView rvhostlist;
//    List<CompanyDataResponse.Datum> getHostlist;
    List<ContactlistGuardResponse.Datum> getContactlist;
//    int hostimage[] = {R.drawable.guru, R.drawable.guru, R.drawable.sanjay, R.drawable.guru, R.drawable.sanjay,
//            R.drawable.guru, R.drawable.sanjay, R.drawable.guru, R.drawable.sanjay, R.drawable.guru};
//    String hostname[], hostposs[];


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host);

        host_back = findViewById(R.id.host_back);
//        hostname = getResources().getStringArray(R.array.visitorname);
//        hostposs = getResources().getStringArray(R.array.visitorposs);


        host_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                overridePendingTransition(R.anim.trans_left_in, R.anim.trans_left_out);

            }
        });
/*        rvhostlist = findViewById(R.id.rvhostlist);

        getHostlist = new ArrayList<>();

        getHostList hostlist = new getHostList();
        hostlist.setHostposs("Android DEveloper");
        hostlist.setHostName("Mayur Zalavadiya");
        hostlist.setHostImg("http://goo.gl/gEgYUd");

        for (int i = 0; i < 15; i++)
            getHostlist.add(hostlist);*/

        rvhostlist = findViewById(R.id.rvhostlist);

        contactlist();
       /* getHostlist = new ArrayList<>();
        for (int i = 0; i < 10; i++) {

            getHostList getHostListall = new getHostList();
            getHostListall.setHostposs(hostposs[i]);
            getHostListall.setHostName(hostname[i]);
            getHostListall.setHostImage(hostimage[i]);


            getHostlist.add(getHostListall);
        }*/
//        hostListAdapter hostListAdapter = new hostListAdapter(this, getHostlist,hostimage,hostname,hostposs);
        rvhostlist.setLayoutManager(new LinearLayoutManager(this));
        rvhostlist.setItemAnimator(new DefaultItemAnimator());
//        rvhostlist.setAdapter(hostListAdapter);

    }

    private void contactlist() {
        if (Utility.isInternetAvailable(HostActivity.this)){
            RestClient.getInstance().getApiInterface().contactlist_guard_response().enqueue(new Callback<ContactlistGuardResponse>() {
                @Override
                public void onResponse(Call<ContactlistGuardResponse> call, Response<ContactlistGuardResponse> response) {
                    if (response.body().getData().size() > 0) {
                        getContactlist = response.body().getData();
                        hostListAdapter hostListAdapter = new hostListAdapter(HostActivity.this, getContactlist);
                        rvhostlist.setAdapter(hostListAdapter);
                        hostListAdapter.notifyDataSetChanged();
                    } else {
                        Utility.showMessage(HostActivity.this, false, response.body().getMessage());
                    }
                }

                @Override
                public void onFailure(Call<ContactlistGuardResponse> call, Throwable t) {

                }
            });
        }else {

        }

    }

    @Override
    public void onBackPressed() {
        PrefsManager.removeKey(PrefsManager.VISITOR_PURPOSE_ID);
        overridePendingTransition(R.anim.trans_right_in, R.anim.trans_right_out);
        super.onBackPressed();

    }
}