package com.tgate.gate.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.tgate.gate.R;
import com.tgate.gate.model.getCheckoutList;

import java.util.List;

public class checkoutListAdapter extends RecyclerView.Adapter<checkoutListAdapter.MyHolder> {
    Context context;
    List<getCheckoutList> getCheckoutList;
    int iamge[];
    String name[];

    public checkoutListAdapter(Context context, List<getCheckoutList> getCheckoutList, int[] iamge, String[] name) {
        this.context = context;
        this.getCheckoutList = getCheckoutList;
        this.iamge = iamge;
        this.name = name;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_checkout_list, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.txt_name.setText(getCheckoutList.get(position).getName());
        Glide.with(context).load(getCheckoutList.get(position).getImage()).into(holder.img_userimg);

        holder.txt_checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                    BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(v.getContext(), R.style.alertDialogThem);
                    bottomSheetDialog.setContentView(R.layout.dialog_checkout);
                    bottomSheetDialog.setCanceledOnTouchOutside(true);

                    ImageView img_close = bottomSheetDialog.findViewById(R.id.img_close);
                    img_close.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            bottomSheetDialog.dismiss();
                        }
                    });
                    bottomSheetDialog.show();

                    holder.txt_checkout.setText("Check In");
                    holder.txt_checkout.setBackground(context.getResources().getDrawable(R.drawable.bg_checkin));


            }
        });
    }



    @Override
    public int getItemCount() {
        return getCheckoutList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        ImageView img_userimg;
        AppCompatTextView txt_name, txt_checkout;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            img_userimg = itemView.findViewById(R.id.img_userimg);
            txt_name = itemView.findViewById(R.id.txt_name);
            txt_checkout = itemView.findViewById(R.id.txt_checkout);

        }
    }
}
