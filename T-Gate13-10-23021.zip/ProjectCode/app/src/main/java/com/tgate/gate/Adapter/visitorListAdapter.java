package com.tgate.gate.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.tgate.gate.R;
import com.tgate.gate.model.getVisitorList;

import java.util.List;

public class visitorListAdapter extends RecyclerView.Adapter<visitorListAdapter.myVisitorListHolder> {
    Context context;
    List<getVisitorList> getVisitorList;
    String visitorname[], visitorposs[], visitorexp[];
    int counter=0;

    public visitorListAdapter(Context context, List<getVisitorList> getVisitorList, String[] visitorname, String[] visitorposs, String[] visitorexp) {
        this.context = context;
        this.getVisitorList = getVisitorList;
        this.visitorname = visitorname;
        this.visitorposs = visitorposs;
        this.visitorexp = visitorexp;
    }

    @NonNull
    @Override
    public myVisitorListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_visitor_list, parent, false);
        return new myVisitorListHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myVisitorListHolder holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(context).load(getVisitorList.get(position).getVisitorImage()).into(holder.img_userimg);

        holder.txt_name.setText(getVisitorList.get(position).getVisitorName());
        holder.txt_poss.setText(getVisitorList.get(position).getVisitorposs());
        holder.txt_exp.setText(getVisitorList.get(position).getVisitorexp());


        holder.txt_accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(v.getContext(), R.style.alertDialogThem);
                    bottomSheetDialog.setContentView(R.layout.dialog_mettingguard);
                    bottomSheetDialog.setCanceledOnTouchOutside(true);

                    ImageView img_close = bottomSheetDialog.findViewById(R.id.img_close);
                    img_close.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            bottomSheetDialog.dismiss();
                        }
                    });
                    bottomSheetDialog.show();

                    holder.txt_accept.setText("Rejected");
                    holder.txt_accept.setBackground(context.getResources().getDrawable(R.drawable.bg_rejected));



            }
        });


    }

    @Override
    public int getItemCount() {
        return getVisitorList.size();
    }

    public class myVisitorListHolder extends RecyclerView.ViewHolder {

        ImageView img_userimg;
        AppCompatTextView txt_name, txt_poss, txt_exp, txt_accept;

        public myVisitorListHolder(@NonNull View itemView) {
            super(itemView);
            img_userimg = itemView.findViewById(R.id.img_userimg);
            txt_name = itemView.findViewById(R.id.txt_name);
            txt_poss = itemView.findViewById(R.id.txt_poss);
            txt_exp = itemView.findViewById(R.id.txt_exp);
            txt_accept = itemView.findViewById(R.id.txt_accept);
        }
    }
}
