package com.tgate.gate.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;
import com.tgate.gate.R;
import com.tgate.gate.util.PrefsManager;
import com.tgate.gate.util.Utility;

public class MainActivity extends AppCompatActivity {


    CardView visitor, checkin, checkout, host;

    DrawerLayout drawerlayout;
    MaterialToolbar toolbar;
    NavigationView navigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);


        visitor = findViewById(R.id.visitor);
        visitor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utility.Intent(MainActivity.this, VisitorsActivity.class);
            }
        });

        checkin = findViewById(R.id.checkin);
        checkin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PrefsManager.removeKey(PrefsManager.VISITOR_PURPOSE_ID);
                Utility.Intent(MainActivity.this, CheckinActivity.class);
                overridePendingTransition(R.anim.trans_left_in, R.anim.trans_left_out);
            }
        });

        checkout = findViewById(R.id.checkout);
        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utility.Intent(MainActivity.this, CheckOutActivity.class);
                overridePendingTransition(R.anim.trans_left_in, R.anim.trans_left_out);
            }
        });

        host = findViewById(R.id.host);
        host.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utility.Intent(MainActivity.this, HostActivity.class);
                overridePendingTransition(R.anim.trans_left_in, R.anim.trans_left_out);
            }
        });

        toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
        drawerlayout = findViewById(R.id.drawerlayout);
        navigation = findViewById(R.id.navigation);

//        toolbar.setNavigationIcon(R.drawable.icon_menu);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerlayout.openDrawer(GravityCompat.START);
            }
        });



        navigation.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
//                drawerlayout.closeDrawer(GravityCompat.START);
                switch (id) {
                    case R.id.my_profile:
                        Utility.Intent(MainActivity.this, EditVisitorDetails.class);
                        drawerlayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.logout:
                        drawerlayout.closeDrawer(GravityCompat.START);
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);

                        alertDialogBuilder
                                .setTitle("Logout")
                                .setMessage("Are you sure to logout?")
                                .setCancelable(false)
                                .setPositiveButton("LOGOUT", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        PrefsManager.removeAllKey();
                                        Utility.Intent(MainActivity.this,LoginActivity.class);
                                        finish();

                                    }
                                })

                                .setNegativeButton("cancle", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        dialog.dismiss();

                                    }
                                });

                        // create alert dialog
                        AlertDialog alertDialog = alertDialogBuilder.create();

                        // show it
                        alertDialog.show();

                        break;

//                    default:
//                    return true;
                }
                return true;
            }
        });

    }


    @Override
    public void onBackPressed() {
        if (drawerlayout.isDrawerOpen(navigation)) {
            drawerlayout.closeDrawer(navigation, true);
        } else {
            super.onBackPressed();
        }
    }
}